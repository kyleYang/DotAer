/*
 
 Adview .
 
 */

#import "AdViewAdapterOpenAPI.h"
#import "KOpenAPIAdView.h"


/*Adview openapi ad -- inmobi.*/

@interface AdViewAdapterInMobi : AdViewAdapterOpenAPI {
    
}

+ (AdViewAdNetworkType)networkType;

@end
