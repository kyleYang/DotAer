/*
 adview openapi ad-InMobi.
 */

#import "AdViewViewImpl.h"
#import "AdViewConfig.h"
#import "AdViewAdNetworkConfig.h"
#import "AdViewDelegateProtocol.h"
#import "AdViewLog.h"
#import "AdViewAdNetworkAdapter+Helpers.h"
#import "AdViewAdNetworkRegistry.h"
#import "AdViewAdapterInMobi.h"
#import "AdViewExtraManager.h"

@interface AdViewAdapterInMobi ()
@end


@implementation AdViewAdapterInMobi

+ (AdViewAdNetworkType)networkType {
    return AdViewAdNetworkTypeInMobi;
}

+ (void)load {
	if(NSClassFromString(@"KOpenAPIAdView") != nil) {
		[[AdViewAdNetworkRegistry sharedRegistry] registerClass:self];
	}
}

- (int)OpenAPIAdType {
    return KOPENAPIADTYPE_INMOBI;
}

- (NSString *) appId {
	NSString *apID;
	if ([adViewDelegate respondsToSelector:@selector(inmobiApIDString)]) {
		apID = [adViewDelegate inmobiApIDString];
	}
	else {
		apID = networkConfig.pubId;
	}
	
	return apID;
	
#if 0
	return @"4f0acf110cf2f1e96d8eb7ea";		//4f0acf110cf2f1e96d8eb7ea
#endif
}

@end
